export const colors = {
  darkBlue: '#252250',
  white: '#fff'
}